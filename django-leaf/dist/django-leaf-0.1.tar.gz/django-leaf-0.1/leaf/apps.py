# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class LeafConfig(AppConfig):
    name = 'python_django.django-leaf.leaf'
